# -*- coding: utf8 -*- 
from selenium import webdriver
driver = webdriver.Firefox()

driver.get("https://pan.baidu.com/s/1oAeeJyy") 
driver.refresh()